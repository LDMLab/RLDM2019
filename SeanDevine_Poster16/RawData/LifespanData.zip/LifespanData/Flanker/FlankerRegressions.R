# regression analyses with simple effects analysis (Maxwell & Delaney, 2004)
library(afex)
setwd("C://Users//LSDMlab_RA//Desktop//LifespanData//Flanker")
d <- read.csv("FlankerData.csv")

d$prev_error <- ifelse(d$prev_error==0, 'no_pe', 'pe')
d$prev_timeout <- ifelse(d$prev_timeout==0, 'no_pto', 'pto')
d$same_resp <- ifelse(d$same_resp==0, 'same', 'diff')
d$stim_rep <- ifelse(d$stim_rep==0, 'rep', 'norep')

for (id in unique(d$id)){
  d.subject <- d[d$id == id,]
  
  d[d$id == id, ]$reward_rate_s <- scale(d.subject$reward_rate, center = TRUE, scale = TRUE)
  d[d$id == id, ]$reward_s <- scale(d.subject$reward, center = TRUE, scale = TRUE)
  d[d$id == id, ]$duration_s <- scale(d.subject$duration, center = TRUE, scale = TRUE)
  
}
##RT
d$logRT <- log(d$RT)
mRT <- mixed(logRT ~ age_group*reward_rate_s*trial_type + reward_s  + stim_rep + prev_error + same_resp + duration_s + (1 + trial_type + reward_rate_s + reward_s + prev_type + prev_error + same_resp + duration_s | id), 
             data = d, na.action = na.omit, method = "S",
             control = lmerControl(calc.derivs = F))
#if significant interaction
mRTCH <- mixed(logRT ~ reward_rate_s*trial_type + reward_s  + stim_rep + prev_error + same_resp + duration_s + (1 + trial_type + reward_rate_s + reward_s + prev_type + prev_error + same_resp + duration_s | id), 
               data = d[d$age_group=='CH',], na.action = na.omit, method = "S",
               control = lmerControl(calc.derivs = F))
mRTAD <- mixed(logRT ~ reward_rate_s*trial_type + reward_s  + stim_rep + prev_error + same_resp + duration_s + (1 + trial_type + reward_rate_s + reward_s + prev_type + prev_error + same_resp + duration_s | id), 
               data = d[d$age_group=='AD',], na.action = na.omit, method = "S",
               control = lmerControl(calc.derivs = F))
mRTYA <- mixed(logRT ~ reward_rate_s*trial_type + reward_s  + stim_rep + prev_error + same_resp + duration_s + (1 + trial_type + reward_rate_s + reward_s + prev_type + prev_error + same_resp + duration_s | id), 
               data = d[d$age_group=='YA',], na.action = na.omit, method = "S",
               control = lmerControl(calc.derivs = F))
mRTOA <- mixed(logRT ~ reward_rate_s*trial_type + reward_s  + stim_rep + prev_error + same_resp + duration_s + (1 + trial_type + reward_rate_s + reward_s + prev_type + prev_error + same_resp + duration_s | id), 
               data = d[d$age_group=='OA',], na.action = na.omit, method = "S",
               control = lmerControl(calc.derivs = F))

##accuracy
mACC <- mixed(accuracy ~ age_group + trial_type + reward_rate_s + reward_s + stim_rep + prev_type + prev_error + same_resp + age_group:trial_type + age_group:reward_rate_s + trial_type:reward_rate_s + age_group:trial_type:reward_rate_s + (1 + trial_type + reward_rate_s + reward_s + stim_rep + prev_type + prev_error + same_resp | id), 
              family = binomial, data = d, 
              method = "LRT", 
              control = glmerControl(calc.derivs = F))

#if significant interaction
mACCCH <- mixed(accuracy ~ trial_type + reward_rate_s + reward_s + stim_rep + prev_type + prev_error + same_resp + trial_type:reward_rate_s + (1 + trial_type + reward_rate_s + reward_s + stim_rep + prev_type + prev_error + same_resp | id), 
                family = binomial, data = d[d$age_group=='CH',], 
                method = "LRT", 
                control = glmerControl(calc.derivs = F))
mACCAD <- mixed(accuracy ~ trial_type + reward_rate_s + reward_s + stim_rep + prev_type + prev_error + same_resp + trial_type:reward_rate_s + (1 + trial_type + reward_rate_s + reward_s + stim_rep + prev_type + prev_error + same_resp | id), 
                family = binomial, data = d[d$age_group=='AD',],
                method = "LRT", 
                control = glmerControl(calc.derivs = F))
mACCYA <- mixed(accuracy ~ trial_type + reward_rate_s + reward_s + stim_rep + prev_type + prev_error + same_resp + trial_type:reward_rate_s + (1 + trial_type + reward_rate_s + reward_s + stim_rep + prev_type + prev_error + same_resp | id), 
                family = binomial, data = d[d$age_group=='YA',], 
                method = "LRT", 
                control = glmerControl(calc.derivs = F))
mACCOA <- mixed(accuracy ~ trial_type + reward_rate_s + reward_s + stim_rep + prev_type + prev_error + same_resp + trial_type:reward_rate_s + (1 + trial_type + reward_rate_s + reward_s + stim_rep + prev_type + prev_error + same_resp | id), 
                family = binomial, data = d[d$age_group=='OA',], 
                method = "LRT", 
                control = glmerControl(calc.derivs = F))

#save output
capture.output(c('overall:', mRT, 'Children:', mRTCH, 'Adolescents:', mRTAD, 'Young Adults: ',mRTYA, 'Old Adults:', mRTOA), file = "output/regressions/RTreg.txt")
capture.output(c('overall', mACC, 'Children: ', mACCCH, 'Adolescents: ', mACCAD, 'Young Adults: ', mACCYA, 'Older Adults: ', mACCOA), file = "output/regressions/ACCreg.txt")




