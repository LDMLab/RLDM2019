#Reward rate calculation and splitting 
RR_calc <- function(learning_rate, d){
  
  alpha <- learning_rate # learning rate (see Flanker optimization route); past alpha = 0.003368421
  
  # iterate over subjects
  for(id in unique(d$id)) {
    # get subset data for subject
    d.subject <- d[d$id==id,]
    # compute reward rate for entire experiment
    avg_rew <- sum(d.subject$reward_obtained) / ((max(d.subject$Flanker.OnsetTime)-min(d.subject$Flanker.OnsetTime))/1000)
    # get start time of experiment
    last_time <- d[d$id==id & d$trial==1,]$Fixation.OnsetTime - d[d$id==id & d$trial==1,]$duration - 200
    # iterate over trials
    for(t in 1:max(d.subject$trial)) {
      d[d$id==id & d$trial==t,'reward_rate'] <- avg_rew
      # get subset data for trial (one row)
      d.trial <- d.subject[d.subject$trial==t,]
      # get time elapsed since last trial
      tau <- (d.trial$Flanker.OnsetTime - last_time)/1000
      # update reward rate
      avg_rew <- ((1-alpha)^tau)*avg_rew + (1- (1-alpha)^tau) * (d.trial$reward_obtained / tau)
      # save time of trial
      last_time <- d.trial$Flanker.OnsetTime
    }
    # median and tertile split on reward rate and raw reward (we will usually exclude the middle tertile)
    median_reward_rate <- median(d[d$id==id,]$reward_rate)
    tertile <- quantile(d[d$id == id,]$reward_rate, c(.33, .66, .99))
    tertile_r <- quantile(d[d$id == id,]$reward, c(.33, .66, .99))
    for(t in 1:max(d.subject$trial)) {
      reward_rate <- d[d$id==id & d$trial==t,]$reward_rate
      reward <- d[d$id==id & d$trial==t,]$reward
      d[d$id==id & d$trial==t,'reward_rate_split'] <- ifelse(reward_rate>median_reward_rate,'high','low')
      d[d$id==id & d$trial==t,'tertile_rewardrate_split'] <- ifelse(reward_rate < tertile[1], "low", ifelse(reward_rate > tertile[2], "high", "medium"))
      d[d$id==id & d$trial==t,'tertile_reward_split'] <- ifelse(reward < tertile_r[1], "low", ifelse(reward > tertile_r[2], "high", "medium"))
    }
  }
  d$reward_rate_split <- factor(d$reward_rate_split, c('low', 'high'))
  d$tertile_rewardrate_split <- factor(d$tertile_rewardrate_split, c('low', 'medium', 'high'))
  d$tertile_reward_split <- factor(d$tertile_reward_split, c('low', 'medium', 'high'))
  return(d)}
