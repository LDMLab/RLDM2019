#regression analyses with simple effects analysis (Maxwell & Delaney, 2004)
library(afex)

setwd("C://Users//LSDMlab_RA//Desktop//LifespanData//TS")
d <- read.csv("TSData.csv")

#within-subject scale variables
for (id in unique(d$id)){
  d.subject <- d[d$id == id,]
  
  d[d$id == id, ]$reward_rate_s <- scale(d.subject$reward_rate, center = TRUE, scale = TRUE)
  d[d$id == id, ]$reward_s <- scale(d.subject$reward, center = TRUE, scale = TRUE)
  d[d$id == id, ]$duration_s <- scale(d.subject$duration, center = TRUE, scale = TRUE)
  
}

#minimal models 
#RT
d$logRT <- log(d$RT)
mRT <- mixed(logRT ~ age_group*trial_type*reward_rate_s*reward_s*version + (1 + trial_type + reward_rate_s + reward_s | id), 
             data = d, na.action = na.omit, method = "S", 
             control = lmerControl(calc.derivs = F))


emmeans(mRT, list(pairwise ~ age_group), adjust = "tukey") #age follow-up

#if significant interaction
mRTCH <- mixed(logRT ~ trial_type*reward_rate_s*reward_s*version + (1 + trial_type + reward_rate_s + reward_s | id), 
               data = d[d$age_group=='CH',], na.action = na.omit, method = "S",
               control = lmerControl(calc.derivs = F))
mRTAD <- mixed(logRT ~ trial_type*reward_rate_s*reward_s*version + (1 + trial_type + reward_rate_s + reward_s | id), 
               data = d[d$age_group=='AD',], na.action = na.omit, method = "S",
               control = lmerControl(calc.derivs = F))
mRTYA <- mixed(logRT ~ trial_type*reward_rate_s*reward_s*version + (1 + trial_type + reward_rate_s + reward_s | id), 
               data = d[d$age_group=='YA',], na.action = na.omit, method = "S",
               control = lmerControl(calc.derivs = F))
mRTOA <- mixed(logRT ~ trial_type*reward_rate_s*reward_s*version + (1 + trial_type + reward_rate_s + reward_s | id), 
               data = d[d$age_group=='OA',], na.action = na.omit, method = "S",
               control = lmerControl(calc.derivs = F))

mRTYA_switch <- mixed(logRT ~ reward_rate_s*reward_s*version + (1 + reward_rate_s + reward_s | id), 
                      data = d[d$age_group=='YA' & d$trial_type=='switch',], na.action = na.omit, method = "S",
                      control = lmerControl(calc.derivs = F))

mRTYA_rep <- mixed(logRT ~ reward_rate_s*reward_s*version + (1 + reward_rate_s + reward_s | id), 
                      data = d[d$age_group=='YA' & d$trial_type=='repeat',], na.action = na.omit, method = "S",
                      control = lmerControl(calc.derivs = F))

capture.output(c('overall:', mRT, 'Children:', mRTCH, 'Adolescents:', mRTAD, 'Young Adults: ',mRTYA, 'Old Adults:', mRTOA), file = "output/regressions/RTregmin_noversion.txt")
capture.output(c('overall:', summary(mRT), 'Children:', summary(mRTCH), 'Adolescents:', summary(mRTAD), 'Young Adults: ', summary(mRTYA), 'Old Adults:', summary(mRTOA)), file = "output/regressions/sumRTregmin.txt")

#ACC
mACCmin <- mixed(accuracy ~ age_group*trial_type*reward_rate_s*reward_s + (1 + trial_type + reward_rate_s + reward_s | id), 
              family = binomial, data = d, 
              method = "LRT", 
              control = glmerControl(calc.derivs = F))

emmeans(mACCmin, list(pairwise ~ age_group), adjust = "tukey") #age follow-up

#if significant interaction
mACCCHmin <- mixed(accuracy ~ trial_type*reward_rate_s* reward_s + (1 + trial_type + reward_rate_s + reward_s | id), 
                family = binomial, data = d[d$age_group=='CH',],
                method = "LRT", 
                control = glmerControl(calc.derivs = F))
mACCADmin <- mixed(accuracy ~ trial_type*reward_rate_s*reward_s + (1 + trial_type + reward_rate_s + reward_s | id), 
                family = binomial, data = d[d$age_group=='AD',],
                method = "LRT", 
                control = glmerControl(calc.derivs = F))
mACCYAmin <- mixed(accuracy ~ trial_type*reward_rate_s*reward_s + (1 + trial_type + reward_rate_s + reward_s | id), 
                family = binomial, data = d[d$age_group=='YA',],
                method = "LRT", 
                control = glmerControl(calc.derivs = F))
mACCOAmin <- mixed(accuracy ~ trial_type*reward_rate_s*reward_s + (1 + trial_type + reward_rate_s + reward_s | id), 
                family = binomial, data = d[d$age_group=='OA',],
                method = "LRT", 
                control = glmerControl(calc.derivs = F))

capture.output(c('overall:', mACCmin, 'Children:', mACCCHmin, 'Adolescents:', mACCADmin, 'Young Adults:', mACCYAmin, 'Older Adults:', mACCOAmin), file = "output/regressions/ACCregmin.txt")
capture.output(c('overall:', summary(mACCmin), 'Children:', summary(mACCCHmin), 'Adolescents:', summary(mACCADmin), 'Young Adults:', summary(mACCYAmin), 'Older Adults:', summary(mACCOAmin)), file = "output/regressions/sumACCregmin.txt")

